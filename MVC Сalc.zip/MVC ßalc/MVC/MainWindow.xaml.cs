﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MVC
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		public enum Operation
		{
			Plus, Minus, Multiply, Divide, Percent
		}
		private Operation op;
		private static int result = 0;

		private void CalculateButton_Click(object sender, RoutedEventArgs e) //Метод, который вызывается при нажатии на кнопку "Посчитать"
		{
			// controller
			//Валидация полученных данных
			string text1 = Num1TextBox.Text.Trim();
			string text2 = Num2TextBox.Text.Trim();
			int num1 = 0;
			int num2 = 0;
			if (!string.IsNullOrEmpty(text1) && !string.IsNullOrEmpty(text2))
			{
				try
				{
					num1 = Convert.ToInt32(text1);
					num2 = Convert.ToInt32(text2);
				}
				catch (Exception) { }

				Calculate(op, num1, num2); //Передача данных модели
			}
		}

		public static int Result;

		public void UpdateView()
		{
			// view
			ResultTextBlock.Text = result.ToString(); //Изменение вида
		}

		public void Calculate(Operation operation, int num1, int num2)
		{
			// model
			switch (operation)
			{
				case Operation.Plus:
					result = num1 + num2;
					break;
				case Operation.Minus:
					result = num1 - num2;
					break;
				case Operation.Multiply:
					result = num1 * num2;
					break;
				case Operation.Divide:
					result = num1 / num2;
					break;
				case Operation.Percent:
					result = num1 / 100 * num2;
					break;
			}
			UpdateView(); //Вызов обновления представления
		}

		private void textBlock_operation_TextChanged(object sender, TextChangedEventArgs e)
		{
			switch (textBlock_operation.Text)
			{
				case "+":
					op = Operation.Plus;
					break;
				case "-":
					op = Operation.Minus;
					break;
				case "*":
					op = Operation.Multiply;
					break;
				case "/":
					op = Operation.Divide;
					break;
				case "%":
					op = Operation.Percent;
					break;
			}
		}
	}
}
